function toTitleCase(str) {
    return str.replace(/\w\S*/g, function(txt){
        return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
    });
}

const Help = {
  name: "Help",
  command: "help",
  category: "Utility",
  description: "Displays Help Commands",
  usage: "help",
  execute: async function(client, msg, args, embed, guildSettings) {
      let categories = ["bot", "services", "support"]
      embed.setDescription("For additional info on a command, type ``"+ guildSettings.prefix + "help <category>``")
      if (!args[0]) {
          categories.forEach(category => {
              // let cmds = client.commands.filter(command => command.command === category.command)
  
              embed.addField(`❯ `+toTitleCase(category)+` Module`, "Use `"+guildSettings.prefix+"help "+toTitleCase(category)+"` to view commands.", false)
              embed.setColor(guildSettings.colorScheme)
          })
      } else {
          if (!categories.includes(args[0].toLowerCase())) {
              embed.setDescription(`Hm.. I was unable to find that category! Please say ${guildSettings.prefix}help to see a list of categories.`)
              embed.setColor("ORANGE")
          }
          let cmds = client.commands.filter(command => command.category.toLowerCase() === args[0].toLowerCase())
          cmds.each(cmd => {
              embed.addField(cmd.name, `Command: \`${cmd.command}\`\nDescription: ${cmd.description}\nUsage: \`${cmd.usage}\`\n\n`)
              embed.setColor(guildSettings.colorScheme)
          })
      }
      embed.setTitle(`${msg.guild.name} Command List`)
      msg.channel.send(embed)
  }
}

module.exports = Help