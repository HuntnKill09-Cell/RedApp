const DM = {
    name: "DM",
    command: "dmsus",
    category: "Support",
    description: "DM a user from the bot.",
    usage: "dmsus <@user> <message>",
    execute: async function(client, msg, args, embed, guildSettings) {

        

        if (!guildSettings.modroleid){
            embed.setTitle(":pensive: Command Error")
            embed.setDescription(`A server administrator needs to set the Moderator Role ID and/or the Log Channel ID. This can be done [here](https://vortexhq.net/servers/${msg.guild.id}/utility).`)
            embed.setColor("RED")
            msg.channel.send(embed)
        } else {
        if (!msg.member.roles.cache.has(`${guildSettings.modroleid}`)) {
            embed.setTitle(":pensive: Command Error")
            embed.setColor("RED")
            embed.setDescription(`You must have the <@&${guildSettings.modroleid}> role to use this command!`)
            return msg.channel.send(embed)
        }

        if (!args[0]) {
            embed.setTitle(":pensive: Command Error")
            embed.setColor("RED")
            embed.setDescription("Please mention the user you wish to DM!")
            return msg.channel.send(embed)
        }
        if (!args[1]) {
            embed.setTitle(":pensive: Command Error")
            embed.setColor("RED")
            embed.setDescription("Please provide a message for the DM!")
            return msg.channel.send(embed)
        }
        let user = msg.mentions.users.first() || msg.guild.members.cache.get(args[0])
        let moderator = msg.author
        let message = args.slice(1).join(" ")
        var logchannel = client.channels.cache.get(`${guildSettings.logchannelid}`)
            const Discord = require('discord.js');
        const dmembed = new Discord.MessageEmbed()
        .setTitle(`:pensive: You are currently service banned!`)
        .setDescription("Seems like you are currently banned from accessing all Arulo Platform services, if you believe this was a mistake feel free to email us at **abuse@aruloapp.us.**")
        .addField("Moderator Notes",`${message}`)
        .setColor("RED")
        .setFooter((guildSettings.branding ? "Powered by aruloapp.us" : client.user.username), client.user.avatarURL())
       try{
        user.send(dmembed)
       }catch(err){
        embed.setTitle(":pensive: Command Error")
        embed.setDescription(`I'm unable to send a DM to ${user} because they have their DMs off.`)
        embed.setColor("RED")
        return msg.channel.send(embed)
       }
        console.log("No error yet.")

        embed.setTitle("Got it!")
        embed.setDescription(`I've DMed ${user} with the following message:\n`
        + `\`\`\`${message}\`\`\``)
        msg.channel.send(embed)

      
        
    }
    }}
    module.exports = DM
