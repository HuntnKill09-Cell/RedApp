

const CreatePartner = {
    name: "CreatePartner",
    command: "createpartner",
    category: "Support",
    description: "Displays Help Commands",
    usage: "createpartner",
    execute: async function(client, msg, args, embed, guildSettings) {
      const db = require('../util/database.util')
      const Discord = require('discord.js')
      
      let robloxId = args[0]
      let discord = args.slice(1).join(" ")

      db.partners.create({ reps: "Not Valid", robloxid: robloxId, discordId: discord })



      msg.channel.send('Created partner, run `!partnerinfo` again.')
    }
  }
  
  module.exports = CreatePartner