
const Support = {
  name: "Support",
  command: "support",
  category: "Support",
  description: "Displays Help Commands",
  usage: "support",
  execute: async function(client, msg, args, embed, guildSettings) {
    const db = require('../util/database.util')
    const Discord = require('discord.js')
    let partners = await db.partners.find()
     let specialNote = args[0]
    var channel = msg.guild.channels.cache.get(`991232424740663317`)
    channel.bulkDelete(100)
    const embed2 = new Discord.MessageEmbed();
     const embed3 = new Discord.MessageEmbed();
    
    embed2.setTitle("❓  Contact our Team")
    embed2.setDescription("Hi there! If you are experiancing issues with our platform, we are here to help you. We allow you to contact support via this Discord Server by saying ``-new``.")
    embed2.addField("Customer Support Hours",`9:00 AM EST - 6:00 PM EST
6:00 AM PDT - 3:00 PM PDT
8:00 AM CST - 5:00 PM CST 
`, true)
  embed2.addField("Abuse & Review Hours",`10:00 AM EST - 5:00 PM EST
7:00 AM PDT - 2:00 PM PDT
9:00 AM CST - 4:00 PM CST
`, true)
    embed2.setColor("ORANGE")
    channel.send(embed2)
    msg.channel.send('Successfully updated support info')
  }
}

module.exports = Support
