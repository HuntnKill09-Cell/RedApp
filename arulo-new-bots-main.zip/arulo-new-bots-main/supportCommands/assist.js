

const PartnerInfo = {
  name: "PartnerInfo",
  command: "partnerinfo",
  category: "Support",
  description: "Displays Help Commands",
  usage: "partnerinfo",
  execute: async function(client, msg, args, embed, guildSettings) {
    const db = require('../util/database.util')
    const Discord = require('discord.js')
    let partners = await db.partners.find()
    var channel = msg.guild.channels.cache.get(`984562118508564480`)
    channel.bulkDelete(100)
    const embed2 = new Discord.MessageEmbed();
     const embed3 = new Discord.MessageEmbed();
    
    embed2.setTitle("Partnership Informaton | 🤝")
    embed2.setDescription("Hi there! To partner with Arulo, please open a ticket via our website. You can view our current partners below.")
    embed2.setColor("731DD8")
    channel.send(embed2)
    msg.channel.send('Successfully updated partners')
    partners.forEach(async (partner) => {
      let embed = new Discord.MessageEmbed()
      const noblox = require('noblox.js')

      console.log(partner.robloxid)

      let logo = await noblox.getLogo(partner.robloxid)
      let info = await noblox.getGroup(partner.robloxid)

   

      embed3.setTitle(info.name)
      embed3.addField('Roblox Link', `https://roblox.com/groups/${partner.robloxid}`)
      embed3.addField('Discord Link', partner.discordId)
      embed3.setColor('BLUE')
      embed3.setThumbnail(logo)
      channel.send(embed3)
    })
  }
}

module.exports = PartnerInfo
