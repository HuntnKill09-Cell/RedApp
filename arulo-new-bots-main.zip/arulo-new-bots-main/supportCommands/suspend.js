

const Suspend = {
    name: "Suspend",
    command: "suspend",
    category: "Support",
    description: "Displays Help Commands",
    usage: "suspend",
    execute: async function(client, msg, args, embed, guildSettings) {
      const db = require('../util/database.util')
      const Discord = require('discord.js')
      
      let discordId = args[0]
      let reason = args.slice(1).join(" ")

      db.suspended.create({ discordId: discordId, reason: reason, notes: "Not Provided", userIp: "dunno", expires: "false", moderator: `${msg.author.tag}`, created_on: "Not Provied" })



      msg.channel.send('Successfully suspended the user.')
    }
  }
  
  module.exports = Suspend