const express = require("express");
const FormData = require("form-data");
const fetch = require("node-fetch");
const app = express();
const ejs = require("ejs");
const Discord = require("discord.js");
const db = require('./util/database.util')
const MemberCounters = require('./MemberCounters')

const port = 3000











app.get("/create/:resourceId/:ownerId/:botToken/:guildId/:botPrefix/:botStatus", async (req, res) => {


  const ownerId = req.params["ownerId"];
  const botToken = req.params["botToken"];
  const guildId = req.params["guildId"];
  const botPrefix = req.params["botPrefix"];;

  db.guild.findOne({ guildid: `${guildId}` }).then(doc => {
  
const client = new Discord.Client({
  intents: ["GUILDS"]
})

let bot = {
  client
}

var guildSettings = null

guildSettings = doc

console.log(guildSettings.prefix)

client.slashcommands = new Discord.Collection() 

client.loadSlashCommands = (bot, reload) => require("./handlers/slashcommands")(bot, reload)
client.loadSlashCommands(bot, false)

client.on("interactionCreate", (interaction) => {
  if (!interaction.isCommand()) return 
  if (!interaction.inGuild()) return 

  const slashcmd = client.slashcommands.get(interaction.commandName)

  if (!slashcmd) return 

  const embed = new Discord.MessageEmbed()

  if (interaction.channel.type !== "dm" && interaction.guild.id !== guildSettings.guildid) {
    embed.setTitle("📛 Are you trying to steal bots?")
    embed.setDescription("This bot is linked to another guild already. You can make your own via our [website](https://aruloapp.us). If you think this is an error, please reach out to us via our support chat on our [website](https://aruloapp.us) .")
    embed.setColor("RED")
    embed.setFooter("Powered by aruloapp.us")
    embed.setTimestamp()
    interaction.reply({ embeds: [embed], ephemeral: true }).catch(err => {})
   // return msg.guild.leave()
}




  if (interaction.channel.type === "dm") {
    embed.setTitle("You aren't allowed to use this command here.")
    embed.setColor("RED")
   embed.setDescription(`Commands are not able to be used while in DM's for security reasons.`)
   embed.setFooter("Powered by https://aruloapp.us")
   return msg.channel.send(embed)
 }else{
  slashcmd.run(client, interaction, guildSettings)
 }
})

const guildId = guildSettings.guildid 

client.slashcommands = new Discord.Collection() 

client.loadSlashCommands = (bot, reload) => require("./handlers/slashcommands")(bot, reload)
client.loadSlashCommands(bot, false)

client.on("ready", async () => {
try{
  const guild = client.guilds.cache.get(guildId)

  console.log(guildId)

  if (!guild)
      return console.error(`📛 Seems like ${client.user.username} is not in the server ${guildId}`)
  
  await guild.commands.set([...client.slashcommands.values()])

  function changeStatus(){
    if(guildSettings){
      client.user.setActivity(guildSettings.currentStatus, { type: "PLAYING" })
    }else{
      client.destroy()
    }
  }

changeStatus()
setInterval(changeStatus, 10000)

  console.log(`✔️ Successfully loaded in ${client.slashcommands.size}`)
  console.log(`✔️ ${client.user.username} has logged in!`)
}catch(err){
  console.log(`📛 Seems like ${client.user.username} can't upload slash commands to ${guildId}`)
}
})

client.login(`${botToken}`).then().catch(reason => {
  console.log("Login failed: " + reason);
      return console.log(`📛 Failed to Login to ${doc.botName}`) 
 
}); //login in discord


  })
})


db.guild.find((err, documents) => {
  if (err) return console.log(err)
  documents.forEach(async (doc, i) => {

const client = new Discord.Client({
    intents: ["GUILDS"]
  })
  
  let bot = {
    client
  }

  var guildSettings = null

  guildSettings = doc

  console.log(guildSettings.prefix)
  
  client.slashcommands = new Discord.Collection() 
  
  client.loadSlashCommands = (bot, reload) => require("./handlers/slashcommands")(bot, reload)
  client.loadSlashCommands(bot, false)
  
  client.on("interactionCreate", (interaction) => {
    if (!interaction.isCommand()) return 
    if (!interaction.inGuild()) return 
  
    const slashcmd = client.slashcommands.get(interaction.commandName)
  
    if (!slashcmd) return 

    const embed = new Discord.MessageEmbed()

    if (interaction.channel.type !== "dm" && interaction.guild.id !== guildSettings.guildid) {
      embed.setTitle("📛 Are you trying to steal bots?")
      embed.setDescription("This bot is linked to another guild already. You can make your own via our [website](https://aruloapp.us). If you think this is an error, please reach out to us via our support chat on our [website](https://aruloapp.us) .")
      embed.setColor("RED")
      embed.setFooter("Powered by aruloapp.us")
      embed.setTimestamp()
      interaction.reply({ embeds: [embed], ephemeral: true }).catch(err => {})
     // return msg.guild.leave()
  }

  // Callum || Andre || Kyle \\

  if(interaction.user.id === "474169687287136256" || interaction.user.id === "555194765394837505" || interaction.user.id === "712345927582482512"){
    embed.setTitle("Seems like you have an account limitation set.")
    embed.setDescription("It appears that you are currently blacklisted from using commands across all Arulo Platform bots, feel free to review the reason below for a better understanding.\n\nIf you have any questions, and or conerns feel free to contact us.")
    embed.addField("Limitation Reason","Spamming our services in attempt to bring them offline is not permitted here at Arulo Platform, we take this very seriously as it could harm our services we provide.")
    embed.setColor("RED")
    return interaction.reply({ embeds: [embed], ephemeral: true }).catch(err => {})
  }

  


    if (interaction.channel.type === "dm") {
      embed.setTitle("You aren't allowed to use this command here.")
      embed.setColor("RED")
     embed.setDescription(`Commands are not able to be used while in DM's for security reasons.`)
     embed.setFooter("Powered by https://aruloapp.us")
     return msg.channel.send(embed)
   }else{
    slashcmd.run(client, interaction, guildSettings)
   }
  })
  
  const guildId = guildSettings.guildid 

client.slashcommands = new Discord.Collection() 

client.loadSlashCommands = (bot, reload) => require("./handlers/slashcommands")(bot, reload)
client.loadSlashCommands(bot, false)
  
  client.on("ready", async () => {
  try{
    const guild = client.guilds.cache.get(guildId)

    if (!guild)
        return console.error(`📛 Seems like ${client.user.username} is not in the server ${guildId}`)

    
    await guild.commands.set([...client.slashcommands.values()])

    function changeStatus(){
      if(guildSettings){
        client.user.setActivity(guildSettings.currentStatus, { type: "PLAYING" })
      }else{
        client.destroy()
      }
    }

  changeStatus()
  setInterval(changeStatus, 10000)

    console.log(`✔️ Successfully loaded in ${client.slashcommands.size}`)
    console.log(`✔️ ${client.user.username} has logged in!`)
  }catch(err){
    console.log(`📛 Seems like ${client.user.username} can't upload slash commands to ${guildId}`)
  }
  })

  client.login(`${doc.botToken}`).then().catch(reason => {
    console.log("Login failed: " + reason);
        return console.log(`📛 Failed to Login to ${doc.botName}`) 
   
}); //login in discord


})
})

app.listen(port)