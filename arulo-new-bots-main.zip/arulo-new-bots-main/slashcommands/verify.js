const run = async (client, interaction, guildSettings) => {
    let username = interaction.options.getString("username")
    const Discord = require("discord.js");
    const MessageEmbed = new Discord.MessageEmbed
    const noblox = require('noblox.js')
    var randomEmoji = require('random-emoji');
    const db = require('../util/database.util').linked;



    const embed = new Discord.MessageEmbed()
    const embed2 = new Discord.MessageEmbed()

    try{
    
    if (!interaction.guild.roles.cache.find((r) => r.name === 'Verified')) {
        interaction.guild.roles.create({
          data: {
            name: 'Verified',
          },
        });
        embed.setTitle(':pensive: Command Error');
        embed.setDescription(
          'I was unable to find the **``Verified``** role, I have went ahead and create the role for you. We request that you run **``verify``** again!'
        );
        embed.setColor('RED');
        return interaction.channel.send(embed);
      } else {
        role = interaction.guild.roles.cache.find((r) => r.name === 'Verified');
      }

      let check = false;

      try {
        check = await linked.findOne({ discordId: interaction.user.id });
      } catch (err) {
        console.log("📛 Seems as if the user isn't yet verified with Arulo.");
        check = "Invalid User"
      }


      if(check !== "Invalid User"){
        console.log("Found the user in the DB!")
      }else{
        const emojis = randomEmoji.random({ count: 5 });
        const emojiList = emojis.map((emoji) => emoji.character).join(' ');

        const getUserId = await noblox.getIdFromUsername(username)
        let getUsername2 = await noblox.getUsernameFromId(getUserId)

        embed.setTitle(`:wave: Hey there, <@${interaction.user.id}>! Let's get started.`)
        embed.setDescription(`If you wish to access this server, we request that you verify with your **Roblox Account**. When you feel as if you are ready, feel free to copy the code below and paste it into your Roblox Profile. [here](https://www.roblox.com/users/${getUserId}/profile)`)
        embed.addField("Verification Code",`> ${emojiList}`, true)
        embed.addField("Pending Account",`> ${getUsername2}`, true)
        embed.setTimestamp()
        embed.setFooter(`${interaction.guild.name} Verification`)

        await interaction.reply({ embeds: [embed], ephemeral: true }).catch(err => {})

        db.create({
            discordId: interaction.user.id,
            robloxId: getUserId,
            status: 'no',
          });

        async function checkProfile(){

            db.find((err, documents) => {
                if (err) return console.log(err)
                documents.forEach(async (doc, i) => {

                    if(doc.discordId === `${interaction.user.id}` && doc.status === "yes"){

                        let getUsername = await noblox.getUsernameFromId(getUserId)

                        embed2.setTitle(`👍 Hey, you are now verified!`)
                        embed2.setDescription(`Welcome to ${interaction.guild.name}, we have successfully linked your Discord account to **${getUsername}**.\n\nIf we connected you to the wrong Roblox account, feel free to go ahead and verify again.`)
                        embed2.setTimestamp()
                        embed2.setColor(`${guildSettings.colorScheme}`)
                        embed2.setFooter(`${interaction.guild.name} Verification`)
                        return interaction.user.send({ embeds: [embed2] }).catch(err => {})

                    }else{
                        setInterval(checkProfile, 3000)
                    }

                })
            })
        }

      



    }

  }catch(err){
    embed2.setTitle(":pensive: Command Error")
    embed2.setDescription("Seems like we've ran into an error while executing this command, you can view more details below.")
    embed2.addField("Error Message", `${err}`)
    embed2.setColor("RED")
    return interaction.reply({ embeds: [embed2], ephemeral: true }).catch(err => {})
  }






}

module.exports = {
    name: "verify",
    description: "Connect your Roblox account to your Discord account.",
    options: [
        {
            name: "username",
            description: "What is your Roblox username?",
            type: "STRING",
            required: true
        }
    ],
    run
}