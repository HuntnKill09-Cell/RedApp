const run = async (client, interaction, guildSettings) => {
    let robloxRank = interaction.options.getNumber("roblox_role_id")
    const Discord = require("discord.js");
    const MessageEmbed = new Discord.MessageEmbed
    const noblox = require('noblox.js')

    const db = require('../util/database.util')



    const embed = new Discord.MessageEmbed()
    const embed2 = new Discord.MessageEmbed()

    if (!interaction.member.roles.cache.has(`${guildSettings.modroleid}`)) {
        embed.setTitle(":pensive: Command Error")
        embed.setColor("RED")
        embed.setDescription(`Seems like you don't have the **<@&${guildSettings.modroleid}>** Role, you are not permitted to use this command.`)
        embed.setTimestamp()
        return interaction.reply({ embeds: [embed], ephemeral: true }).catch(err => {})
    }

    if (!guildSettings.colorScheme) {
    embed.setTitle(":pensive: Command Error")
    embed.setDescription(`Seems like this module isn't configured, you can have a server administrator configure this module [here](https://aruloapp.us/app/services/bots/${guildSettings.resourceId}).`)
    embed.setColor("RED")
    embed.addField("Current Module", "Verification")
    embed.setFooter(`Powered by ${interaction.guild.name}`)
    embed.setTimestamp()
    await interaction.reply({ embeds: [embed], ephemeral: true }).catch(err => {})
  } else {

    try{

        db.binds.find((err, documents) => {
            if (err) return console.log(err)
            documents.forEach(async (doc, i) => {

        
                if(doc.robloxRole === robloxRank && doc.guildId === `${interaction.guild.id}`){
                    embed.setTitle(":tada: Command successfully executed.")
                    embed.addField(`Roblox Rank ID`, `${doc.robloxRole}`, true)
                    embed.addField(`Discord Role`, `<@&${doc.discordRole}>`, true)
                    embed.addField(`Bind Status`, `:white_check_mark: **Binded**`, true)
                    embed.setColor(`${guildSettings.colorScheme}`)
                    embed.setTimestamp()
                    interaction.reply({ embeds: [embed], ephemeral: true }).catch(err => {})
                }else{
                    embed.setTitle(":tada:  Command successfully executed.")
                    embed.addField(`Roblox Rank ID`, `${robloxRank}`, true)
                    embed.addField(`Discord Role`, `Not Provided`, true)
                    embed.addField(`Bind Status`, `📛 **Not Binded**`, true)
                    embed.setColor(`${guildSettings.colorScheme}`)
                    embed.setTimestamp()
                    interaction.reply({ embeds: [embed], ephemeral: true }).catch(err => {})
                }

            })
        })
            

    }catch(err){

        embed2.setTitle(":pensive: Command Error")
        embed2.setDescription("Seems like we've ran into an error while executing this command, you can view more details below.")
        embed2.addField("Error Message", `${err}`)
        embed2.setColor("RED")
        return interaction.reply({ embeds: [embed2], ephemeral: true }).catch(err => {})

    }

}


}

module.exports = {
    name: "checkbind",
    description: "Check wheater if a Roblox role is connected to a Discord role.",
    options: [
        {
            name: "roblox_role_id",
            description: "What is the Roblox Role ID you want to check?",
            type: "NUMBER",
            required: true
        }
    ],
    run
}