const run = async (client, interaction, guildSettings) => {
    let suggestion = interaction.options.getString("suggestion")
    const Discord = require("discord.js");
    const MessageEmbed = new Discord.MessageEmbed
    const noblox = require('noblox.js')

    const suggestionmodule = require('../util/database.util').suggestion



    const embed = new Discord.MessageEmbed()
    const embed2 = new Discord.MessageEmbed()

    if (!guildSettings.suggestionid) {
        embed.setTitle(":pensive: Command Error")
        embed.setDescription(`Seems like this module isn't configured, you can have a server administrator configure this module [here](https://aruloapp.us/app/services/bots/${guildSettings.resourceId}).`)
        embed.setColor("RED")
        embed.addField("Current Module", "Utility")
        embed.setFooter(`Powered by ${interaction.guild.name}`)
        embed.setTimestamp()
        await interaction.reply({ embeds: [embed], ephemeral: true }).catch(err => {})
  } else {

    let channel = interaction.guild.channels.cache.get(`${guildSettings.suggestionid}`)
    const guild = interaction.guild.id
    if (!channel || typeof channel === undefined) {
        embed.setTitle(":pensive: Command Error")
        embed.setDescription(`Seems like the Suggestion Channel ID is invalid, yon can have a server administrator configure it [here](https://aruloapp.us/app/services/bots/${guildSettings.resourceId}).`)
        embed.setColor("RED")
        embed.setTimestamp()
        await interaction.reply({ embeds: [embed], ephemeral: true }).catch(err => {})
    }

    embed.setTitle(":tada: Suggestion Posted!")
    embed.setDescription(`Your suggestion is now posted in ${channel} for others to vote on!`)
    embed.setColor("GREEN")
    await interaction.reply({ embeds: [embed], ephemeral: true }).catch(err => {})

    const idstofind = await suggestionmodule.findOne({ guild: interaction.guild.id }).sort({"id": -1})
    const ids = idstofind.id + 1

    embed2.setAuthor(`Suggestion #${ids}`, interaction.user.avatarURL())
    embed2.setDescription(`${suggestion}`)
    embed2.setTimestamp()

    embed.setColor(guildSettings.colorScheme)
            channel.send({ embeds: [embed2], ephemeral: false }).then(m => {
                const idofmsg = m.id
                console.log(m.id)
                console.log(idofmsg)
                m.react('👍')
                m.react('🤷')
                m.react('👎')


                suggestionmodule.create({ guild: interaction.guild.id, user: interaction.user.id, suggestion: suggestion, id: ids, status: "Pending", msgid: idofmsg, userusername: interaction.user.username, useravatar: `https://cdn.discordapp.com/avatars/${interaction.user.id}/${interaction.user.avatar}` })
            })
    
  }





}

module.exports = {
    name: "suggest",
    description: "You can post a new suggestion for this server.",
    options: [
        {
            name: "suggestion",
            description: "What would you like to suggest?",
            type: "STRING",
            required: true
        }
    ],
    run
}