const run = async (client, interaction, guildSettings) => {
    let user = interaction.options.getMember("user")
    let message = interaction.options.getString("message")
    const Discord = require("discord.js");
    const MessageEmbed = new Discord.MessageEmbed
    const noblox = require('noblox.js')

    const db = require('../util/database.util').cases

    const embed = new Discord.MessageEmbed()
    const embed2 = new Discord.MessageEmbed()
    const logEmbed = new Discord.MessageEmbed()
    const userEmbed = new Discord.MessageEmbed()

    if (!interaction.member.roles.cache.has(`${guildSettings.modroleid}`)) {
        embed.setTitle(":pensive: Command Error")
        embed.setColor("RED")
        embed.setDescription(`Seems like you don't have the **<@&${guildSettings.modroleid}>** Role, you are not permitted to use this command.`)
        embed.setTimestamp()
        return interaction.reply({ embeds: [embed], ephemeral: true }).catch(err => {})
    }

    if(user){


        if(!guildSettings.modroleid){
            embed.setTitle(":pensive: Command Error")
            embed.setDescription(`Seems like this server doesn't have a **Moderator Role** listed, you can set one [here](https://aruloapp.us/app/services/bots/${guildSettings.resourceId}).`)
            embed.setColor("RED")
            interaction.reply({ embeds: [embed], ephemeral: true }).catch(err => {})
        }else{


            try{
                embed.setTitle(`Messaged Received from ${interaction.guild.name}`)
                embed.setColor(`${guildSettings.colorScheme}`)
                embed.setDescription(`${message}`)
                embed.setTimestamp()
                user.send({ embeds: [embed] })

                embed2.setTitle(":tada: Successfully executed Command")
                embed2.setDescription(`I've successfully DM'ed ${user} with the message below!.`)
                embed2.addField("Sent Message",`${message}`,true)
                embed2.setColor(`${guildSettings.colorScheme}`)
                interaction.reply({ embeds: [embed2], ephemeral: true }).catch(err => {})
    
            }catch(err){
                embed.setTitle(":pensive: Command Error")
                embed.setDescription(`Seems like ${user} has their DM's turned off, I am unable to DM them.`)
                console.log(err)
                embed.setColor("RED")
                await interaction.reply({ embeds: [embed], ephemeral: true }).catch(err => {})
            }

           


    }
    }

}

module.exports = {
    name: "dm",
    description: "Send a direct message to a specific user in your server.",
    options: [
        {
            name: "user",
            description: "Who would you like to message?",
            type: "USER",
            required: true
        },
        {
            name: "message",
            description: "What is the message you wish to send this user?",
            type: "STRING",
            required: true
        }
    ],
    run
}