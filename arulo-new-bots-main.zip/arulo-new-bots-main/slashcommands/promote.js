const run = async (client, interaction, guildSettings) => {
    let username = interaction.options.getString("username")
    const Discord = require("discord.js");
    const MessageEmbed = new Discord.MessageEmbed
    const noblox = require('noblox.js')

    const suggestionmodule = require('../util/database.util').suggestion



    const embed = new Discord.MessageEmbed()
    const embed2 = new Discord.MessageEmbed()

    if (!guildSettings.groupid) {
        embed.setTitle(":pensive: Command Error")
        embed.setDescription(`Seems like this module isn't configured, you can have a server administrator configure this module [here](https://aruloapp.us/app/services/bots/${guildSettings.resourceId}).`)
        embed.setColor("RED")
        embed.addField("Current Module", "Group Manager")
        embed.setFooter(`Powered by ${interaction.guild.name}`)
        embed.setTimestamp()
        await interaction.reply({ embeds: [embed], ephemeral: true }).catch(err => {})
  } else {

    if (!interaction.member.roles.cache.has(`${guildSettings.modroleid}`)) {
        embed.setTitle(":pensive: Command Error")
        embed.setColor("RED")
        embed.setDescription(`Seems like you don't have the **<@&${guildSettings.modroleid}>** Role, you are not permitted to use this command.`)
        embed.setTimestamp()
        return interaction.reply({ embeds: [embed], ephemeral: true }).catch(err => {})
    }

    try{

        db.binds.find((err, documents) => {
            if (err) return console.log(err)
            documents.forEach(async (doc, i) => {


        const getUser = noblox.getIdFromUsername(`${username}`)
        const prevRank = noblox.getRankNameInGroup(getUser, doc.groupid)

        noblox.setCookie(`${doc.cookie}`).then(function() {
            noblox.promote(doc.groupid, getUser)

            const updatedRank = noblox.getRankNameInGroup(getUser, doc.groupid)

            if(logchannel){
         
                embed2.setTitle(":medal: Group Management")
                embed2.setColor(`${guildSettings.colorScheme}`)
                embed2.setAuthor(interaction.user.username, interaction.user.avatarURL());
                embed2.addField("Roblox Username", `${username}`, true)
                embed2.addField("Previous Rank", `${prevRank}`, true)
                embed2.addField("Requested By", `<@${interaction.user.id}>`, true)
                embed2.addField("Updated Rank", `${updatedRank}`, true)
                embed2.addField("Action", `User Promoted`, true)
                embed2.setTimestamp()
                embed2.setFooter(`${interaction.guild.name} Group Management`)
                logchannel.send({ embeds: [embed2] })
        
            }else{
                embed.setTitle(":pensive: Channel Invalid")
                embed.setDescription("Seems like the logging channel is invalid, we will not be logging this event.")
                embed.setColor("RED")
                interaction.reply({ embeds: [embed], ephemeral: true }).catch(err => {})
            }


        })

        



            })
        })

}catch(err){
    embed2.setTitle(":pensive: Command Error")
    embed2.setDescription("Seems like we've ran into an error while executing this command, you can view more details below.")
    embed2.addField("Error Message", `${err}`)
    embed2.setColor("RED")
    return interaction.reply({ embeds: [embed2], ephemeral: true }).catch(err => {})
}


  }



}

module.exports = {
    name: "promote",
    description: "Allows you to demote the selected user in the configured Roblox Group.",
    options: [
        {
            name: "username",
            description: "What is the username of who you'd like to demote?",
            type: "STRING",
            required: true
        }
    ],
    run
}