const run = async (client, interaction, guildSettings) => {
    let robloxRank = interaction.options.getString("roblox_role_id")
    let discordRole = interaction.options.getRole("discord_role")
    const Discord = require("discord.js");
    const MessageEmbed = new Discord.MessageEmbed
    const noblox = require('noblox.js')

    const db = require('../util/database.util')



    const embed = new Discord.MessageEmbed()
    const embed2 = new Discord.MessageEmbed()

    if (!interaction.member.roles.cache.has(`${guildSettings.modroleid}`)) {
        embed.setTitle(":pensive: Command Error")
        embed.setColor("RED")
        embed.setDescription(`Seems like you don't have the **<@&${guildSettings.modroleid}>** Role, you are not permitted to use this command.`)
        embed.setTimestamp()
        return interaction.reply({ embeds: [embed], ephemeral: true }).catch(err => {})
    }

    if (!guildSettings.colorScheme) {
    embed.setTitle(":pensive: Command Error")
    embed.setDescription(`Seems like this module isn't configured, you can have a server administrator configure this module [here](https://aruloapp.us/app/services/bots/${guildSettings.resourceId}).`)
    embed.setColor("RED")
    embed.addField("Current Module", "Verification")
    embed.setFooter(`Powered by ${interaction.guild.name}`)
    embed.setTimestamp()
    await interaction.reply({ embeds: [embed], ephemeral: true }).catch(err => {})
  } else {

    try{

            
        db.binds.create({
            guildId: `${interaction.guild.id}`,
            discordRole: `${discordRole.id}`,
            robloxRole: `${robloxRank}`
        })
      
        embed.setTitle(":tada: Successfully Bounded Role")
        embed.setDescription(`I've successfully binded the role ${discordRole} to **${robloxRank}**.`)
        embed.setColor(`${guildSettings.colorScheme}`)
        embed.setTimestamp()
        interaction.reply({ embeds: [embed], ephemeral: true }).catch(err => {})



    }catch(err){

        embed2.setTitle(":pensive: Command Error")
        embed2.setDescription("Seems like we've ran into an error while executing this command, you can view more details below.")
        embed2.addField("Error Message", `${err}`)
        embed2.setColor("RED")
        return interaction.reply({ embeds: [embed2], ephemeral: true }).catch(err => {})

    }

}


}

module.exports = {
    name: "bind",
    description: "Binds a Discord Role with a specific Group Rank.",
    options: [
        {
            name: "roblox_role_id",
            description: "What is the role you want to bind with a Discord role? Refer to your Group Admin.",
            type: "STRING",
            required: true
        },
        {
            name: "discord_role",
            description: "What is the Discord role you want to bind with a Roblox role?",
            type: "ROLE",
            required: true
        }
    ],
    run
}