const run = async (client, interaction, guildSettings) => {
    let user = interaction.options.getMember("user")
    const Discord = require("discord.js");
    const MessageEmbed = new Discord.MessageEmbed
    const noblox = require('noblox.js')

    const db = require('../util/database.util')



    const embed = new Discord.MessageEmbed()
    const embed2 = new Discord.MessageEmbed()

    if (!interaction.member.roles.cache.has(`${guildSettings.modroleid}`)) {
        embed.setTitle(":pensive: Command Error")
        embed.setColor("RED")
        embed.setDescription(`Seems like you don't have the **<@&${guildSettings.modroleid}>** Role, you are not permitted to use this command.`)
        embed.setTimestamp()
        return interaction.reply({ embeds: [embed], ephemeral: true }).catch(err => {})
    }

    try{
                embed.setTitle(`:shield: ${interaction.guild.name} Moderation History.`)
                embed.setDescription(`Showing the moderation lookup for ${user}`)
                embed.setTimestamp()
                embed.setFooter(`${interaction.guild.name} Moderation Suite`)

                let userCases = await db.cases.find({ offender: `${user.user.id}` }) // assuming user is tag-only and not id too
          
                userCases.forEach(userCase => {
                    if(userCase.guildId === interaction.guild.id){
                        embed.addField(`Case ${userCase.caseid} - ${userCase.type}`, userCase.reason)
                    }
                })


                interaction.reply({ embeds: [embed], ephemeral: false }).catch(err => {})
            

    }catch(err){

        embed2.setTitle(":pensive: Command Error")
        embed2.setDescription("Seems like we've ran into an error while executing this command, you can view more details below.")
        embed2.addField("Error Message", `${err}`)
        embed2.setColor("RED")
        return interaction.reply({ embeds: [embed2], ephemeral: true }).catch(err => {})

    }



}

module.exports = {
    name: "history",
    description: "Allows you to check the moderation history of a user.",
    options: [
        {
            name: "user",
            description: "Who is the user you'd like to check the history for?",
            type: "USER",
            required: true
        }
    ],
    run
}