const run = async (client, interaction, guildSettings) => {
    let robloxRank = interaction.options.getNumber("roblox_role_id")
    const Discord = require("discord.js");
    const MessageEmbed = new Discord.MessageEmbed
    const noblox = require('noblox.js')

    const db = require('../util/database.util')



    const embed = new Discord.MessageEmbed()
    const embed2 = new Discord.MessageEmbed()

    if (!guildSettings.colorScheme) {
    embed.setTitle(":pensive: Command Error")
    embed.setDescription(`Seems like this module isn't configured, you can have a server administrator configure this module [here](https://aruloapp.us/app/services/bots/${guildSettings.resourceId}).`)
    embed.setColor("RED")
    embed.addField("Current Module", "Verification")
    embed.setFooter(`Powered by ${interaction.guild.name}`)
    embed.setTimestamp()
    await interaction.reply({ embeds: [embed], ephemeral: true }).catch(err => {})
  } else {

    try{

        db.binds.find((err, documents) => {
            if (err) return console.log(err)
            documents.forEach(async (doc, i) => {

        
                if(doc.robloxRole === robloxRank && doc.guildId === `${interaction.guild.id}`){
             
                    embed.setTitle(":tada: Command successfully executed.")
                    embed.setDescription(`Successfully deleted the bind associated with the <@&${doc.discordRole}> Role.`)
                    embed.setColor(`${guildSettings.colorScheme}`)
                    embed.setTimestamp()
                    doc.delete()
                    interaction.reply({ embeds: [embed], ephemeral: true }).catch(err => {})
                }else{
                    embed2.setTitle(":pensive: Command Error")
        embed2.setDescription("Seems like we've ran into an error while executing this command, you can view more details below.")
        embed2.addField("Error Message", `We failed to find a bind connected with that specific Roblox Role ID`)
        embed2.setColor("RED")
        return interaction.reply({ embeds: [embed2], ephemeral: true }).catch(err => {})
                }

            })
        })
            

    }catch(err){

        embed2.setTitle(":pensive: Command Error")
        embed2.setDescription("Seems like we've ran into an error while executing this command, you can view more details below.")
        embed2.addField("Error Message", `${err}`)
        embed2.setColor("RED")
        return interaction.reply({ embeds: [embed2], ephemeral: true }).catch(err => {})

    }

}


}

module.exports = {
    name: "delbind",
    description: "Delete a bind associated with verification.",
    options: [
        {
            name: "roblox_role_id",
            description: "What is the Roblox Role ID you want to delete?",
            type: "NUMBER",
            required: true
        }
    ],
    run
}