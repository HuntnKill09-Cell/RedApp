const run = async (client, interaction, guildSettings) => {
    let suggestionId = interaction.options.getString("suggestion-id")
    let suggestionStatus = interaction.options.getString("suggestion-status")
    let suggestionComment = interaction.options.getString("comment")
    const Discord = require("discord.js");
    const MessageEmbed = new Discord.MessageEmbed
    const noblox = require('noblox.js')

    const suggestionmodule = require('../util/database.util').suggestion


    console.log(`${suggestionStatus}`)
    const embed = new Discord.MessageEmbed()

    if (!guildSettings.suggestionid) {
    embed.setTitle(":pensive: Command Error")
    embed.setDescription(`Seems like this command hasn't been setup properly, ask a server administrator to review the bot settings [here](https://aruloapp.us/app/services/bots/${guildSettings.resourceId}).`)
    embed.setColor("RED")
    embed.setTimestamp()
    await interaction.reply({ embeds: [embed], ephemeral: true }).catch(err => {})
  } else {

    if (!interaction.member.roles.cache.has(`${guildSettings.modroleid}`)) {
      embed.setTitle(":pensive: Command Error")
      embed.setColor("RED")
      embed.setDescription(`Seems like you don't have the **<@&${guildSettings.modroleid}>** Role, you are not permitted to use this command.`)
      embed.setTimestamp()
      await interaction.reply({ embeds: [embed], ephemeral: true }).catch(err => {})
  }

  let channel = interaction.guild.channels.cache.get(`${guildSettings.suggestionid}`)
  const guild = interaction.guild.id

  const fId = suggestionId
  try {
      await suggestionmodule.findOne({ guild: interaction.guild.id, id: fId })
  } catch {
      embed.setTitle(":pensive: Command Error")
      embed.setDescription(`I was unable to find that suggestion, please see the image below to learn how to locate a suggestion ID.`)
      embed.setColor("RED")
      return await interaction.reply({ embeds: [embed], ephemeral: true }).catch(err => {})
  }

  await interaction.reply({ content: ["Test"], ephemeral: false }).catch(err => {})



  const fetching = await suggestionmodule.findOne({ guild: interaction.guild.id, id: fId })
  const updateSuggestion = fetching.suggestion
  const updateMsgId = fetching.msgid
  const updateId = fetching.id
  const updateUser = fetching.user
  const updateUsername = fetching.userusername
  const updatePfp = fetching.useravatar

  try{
    await channel.messages.fetch(updateMsgId).then(m => {
        if(m){
            console.log("Success")
        }else{
            embed.setTitle(":pensive: Command Error")
            embed.setDescription("Seems like we've ran into an error while executing this command, you can view more details below.")
            embed.addField("Error Message", `${err}`)
            embed.setColor("RED")
            return interaction.reply({ embeds: [embed], ephemeral: true }).catch(err => {})
        }
    })
  }catch(err){
    embed.setTitle(":pensive: Command Error")
            embed.setDescription("Seems like we've ran into an error while executing this command, you can view more details below.")
            embed.addField("Error Message", `${err}`)
            embed.setColor("RED")
            return interaction.reply({ embeds: [embed], ephemeral: true }).catch(err => {})
  }


  if (suggestionStatus.toLowerCase() === "deny") {
    channel.messages.fetch(updateMsgId).then(m => {
        m.embeds.forEach((embed) => {
             const denied = new Discord.MessageEmbed()
            .setAuthor(`Suggestion #${updateId}`, updatePfp)
            .setTimestamp()
            .setColor("RED")
            .setDescription(updateSuggestion)
            .addField(`Suggestion denied by ${interaction.user.tag || interaction.user.user.tag} (${interaction.user.id})`, `${suggestionComment}`)
          if(guildSettings.branding === true){
    denied.setFooter(`Suggested by ${updateUsername} (${updateUser})`)
    denied.setTimestamp()
}else{
    denied.setFooter(`Suggested by ${updateUsername} (${updateUser})`)
    denied.setTimestamp()
}
            try{
        
            m.reactions.removeAll().catch(error => console.error('📛 We encountered an error during command execution: ', error));
            m.edit({ embeds: [denied]}).catch(error => console.error('📛 We encountered an error during command execution: ', error));
            }catch(err){
                return console.log('📛 We encountered an error during command execution: ', err)
            }
        })
        suggestionmodule.findOneAndUpdate({ id: updateId }, {
            status: "Denied",

        })

        embed.setTitle(":tada: Command Success")
        embed.setDescription("I've set that suggestion under `denied`! This message will be deleted in 5 seconds.")
        embed.setColor(`${guildSettings.colorScheme}`)
        embed.setFooter(`Powered by ${interaction.guild.name}`)
        embed.setTimestamp()
        try{
            interaction.reply({ embeds: [embed], ephemeral: true }).then(tod => {
                
            })
        }catch(err){
            return console.log(`📛 We encountered an error during command execution: `, err)
        }
    })
}


    if (suggestionStatus.toLowerCase() === "consider") {
        try{
        channel.messages.fetch(updateMsgId).then(m => {
            m.embeds.forEach((embed) => {
                 const denied = new Discord.MessageEmbed()
                .setAuthor(`Suggestion #${updateId}`, updatePfp)
                .setTimestamp()
                .setColor("ORANGE")
                .setDescription(updateSuggestion)
                .addField(`Suggestion considered by ${interaction.user.tag || interaction.user.user.tag} (${interaction.user.id})`, `${suggestionComment}`)
              if(guildSettings.branding === true){
                denied.setFooter(`Suggested by ${updateUsername} (${updateUser})`)
                denied.setTimestamp()
            }else{
                denied.setFooter(`Suggested by ${updateUsername} (${updateUser})`)
                denied.setTimestamp()
            }
    try{
        m.edit({ embeds: [denied]})
    m.reactions.removeAll().catch(error => console.error('📛 We encountered an error during command execution: ', error));
    }catch(err){
        return console.log('📛 We encountered an error during command execution: ', err)
    }
            })
            suggestionmodule.findOneAndUpdate({ id: updateId }, {
                status: "Considered",
    
            })

            embed.setTitle(":tada: Command Success")
            embed.setDescription("I've set that suggestion under `considered`! This message will be deleted in 5 seconds.")
            embed.setColor(`${guildSettings.colorScheme}`)
            embed.setFooter(`Powered by ${interaction.guild.name}`)
            embed.setTimestamp()
            try{
                interaction.reply({ embeds: [embed], ephemeral: true }).then(tod => {
                  
                })
            }catch(err){
                return console.log(`📛 We encountered an error during command execution: `, err)
            }
        })
    }catch(err){
        return console.log('📛 We encountered an error during command execution: ', err)
    }
    }
      
        if (suggestionStatus.toLowerCase() === "approve") {
            try{
            channel.messages.fetch(updateMsgId).then(m => {
                m.embeds.forEach((embed) => {
                     const denied = new Discord.MessageEmbed()
                    .setAuthor(`Suggestion #${updateId}`, updatePfp)
                    .setTimestamp()
                    .setColor("GREEN")
                    .setDescription(updateSuggestion)
                    .addField(`Suggestion approved by ${interaction.user.tag || interaction.user.user.tag} (${interaction.user.id})`, `${suggestionComment}`)
                  if(guildSettings.branding === true){
                    denied.setFooter(`Suggested by ${updateUsername} (${updateUser})`)
                    denied.setTimestamp()
                }else{
                    denied.setFooter(`Suggested by ${updateUsername} (${updateUser})`)
                    denied.setTimestamp()
                }
        try{
            m.edit({ embeds: [denied]})
        m.reactions.removeAll().catch(error => console.error('📛 We encountered an error during command execution: ', error));
        }catch(err){
            return console.log('📛 We encountered an error during command execution: ', err)
        }
                })
                suggestionmodule.findOneAndUpdate({ id: updateId }, {
                    status: "Approved",
        
                })

                embed.setTitle(":tada: Command Success")
                embed.setDescription("I've set that suggestion under `approved`! This message will be deleted in 5 seconds.")
                embed.setColor(`${guildSettings.colorScheme}`)
                embed.setFooter(`Powered by ${interaction.guild.name}`)
                embed.setTimestamp()
                try{
                    interaction.reply({ embeds: [embed], ephemeral: true }).then(tod => {
                        
                    })
                }catch(err){
                    return console.log(`📛 We encountered an error during command execution: `, err)
                }
  

            })
        }catch(err){
            return console.log('📛 We encountered an error during command execution: ', err)
        }
        }
}


  }


module.exports = {
    name: "suggestion",
    description: "Allows you to either approve/deny/consider an suggestion.",
    options: [
        {
            name: "suggestion-id", description: "What's the suggestion ID of the suggestion you would like to update?",
            type: "STRING", required: true
        },
        {
          name: "suggestion-status",
          description: "Would you like to approve/deny/consider this suggestion?",
          type: "STRING",
          required: false
        },
        {
            name: "comment",
            description: "What's the comment you would like to put for the suggestion?",
            type: "STRING",
            required: false
        }
    ],
    run
}