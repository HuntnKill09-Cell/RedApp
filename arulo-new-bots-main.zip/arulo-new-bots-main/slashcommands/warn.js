const run = async (client, interaction, guildSettings) => {
    let user = interaction.options.getMember("user")
    let reason = interaction.options.getString("reason")
    const Discord = require("discord.js");
    const MessageEmbed = new Discord.MessageEmbed
    const noblox = require('noblox.js')

    const db = require('../util/database.util').cases
    var logchannel = client.channels.cache.get(guildSettings.logchannelid)

    function generateCaseId() {
        return Math.floor(Math.random() * (9999999999 - 100000000 + 1) + 100000000);
    }

    const caseId = generateCaseId();

    const embed = new Discord.MessageEmbed()
    const embed2 = new Discord.MessageEmbed()
    const logEmbed = new Discord.MessageEmbed()
    const userEmbed = new Discord.MessageEmbed()

    if(user){


        if(!guildSettings.modroleid){
            embed.setTitle(":pensive: Command Error")
            embed.setDescription(`Seems like this server doesn't have a **Moderator Role** listed, you can set one [here](https://aruloapp.us/app/services/bots/${guildSettings.resourceId}).`)
            embed.setColor("RED")
            interaction.reply({ embeds: [embed], ephemeral: true }).catch(err => {})
        }else{


            try{
                embed.setTitle(":shield: Server Moderation Notice")
                embed.setColor("ORANGE")
                embed.setDescription(`Hey there, ${user}! You've been successfully warned **${interaction.guild.name}**, you can view more details on this infraction below.`)
                embed.setAuthor(interaction.user.username, interaction.user.avatarURL());
                embed.addField("Moderated Account", `<@${user.id}>`, true)
                embed.addField("Moderator Note", `${reason}`, true)
                embed.addField("Case ID", `${caseId}`, true)
                embed.setTimestamp()
                embed.setFooter(`${interaction.guild.name} Moderation Suite`)
                await user.send({ embeds: [embed] })
    
            }catch(err){
                embed.setTitle(":pensive: Command Error")
                embed.setDescription(`Seems like ${user} has their DM's turned off, I will not be sending them a notification.`)
                embed.setColor("RED")
                await interaction.reply({ embeds: [embed], ephemeral: true }).catch(err => {})
            }

           

        }

        if(logchannel){
         
            logEmbed.setTitle(":shield: Server Moderation")
            logEmbed.setColor(`${guildSettings.colorScheme}`)
            logEmbed.setAuthor(interaction.user.username, interaction.user.avatarURL());
            logEmbed.addField("Moderated Account", `<@${user.id}>`, true)
            logEmbed.addField("Moderator Note", `${reason}`, true)
            logEmbed.addField("Moderator", `${interaction.user.tag || insteraction.user.user.tag}`, true)
            logEmbed.addField("Case ID", `${caseId}`, true)
        logEmbed.setTimestamp()
        logEmbed.setFooter(`${interaction.guild.name} Moderation Suite`)
        logchannel.send({ embeds: [logEmbed] })

        }else{
            embed.setTitle(":pensive: Channel Invalid")
            embed.setDescription("Seems like the logging channel is invalid, we will not be logging this event.")
            embed.setColor("RED")
            interaction.reply({ embeds: [embed], ephemeral: true }).catch(err => {})
        }
        
    if (!interaction.member.roles.cache.has(`${guildSettings.modroleid}`)) {
        embed.setTitle(":pensive: Command Error")
        embed.setColor("RED")
        embed.setDescription(`Seems like you don't have the **<@&${guildSettings.modroleid}>** Role, you are not permitted to use this command.`)
        embed.setTimestamp()
        await interaction.reply({ embeds: [embed], ephemeral: true }).catch(err => {})
    }

    try{

    
        try{
            await user.kick({ reason: `Moderator: ${interaction.user.username}.${reason ? ` Note: ${reason}` : ''}` });
        }catch(err){
            embed2.setTitle(":pensive: Command Error")
            embed2.setDescription("Seems like we've ran into an error while executing this command, you can view more details below.")
            embed2.addField("Error Message", `${err}`)
            embed2.setColor("RED")
            return interaction.reply({ embeds: [embed2], ephemeral: true }).catch(err => {})
        }

        embed2.setTitle(":tada: Command Success")
        embed2.setDescription(`We've successfully warned **<@${user.id}>**, you can view the information below.`)
        embed2.addField("Moderated Account", `<@${user.id}>`, true)
        embed2.addField("Moderator Note", `${reason}`, true)
        embed2.addField("Case ID", `${caseId}`, true)
        embed2.setTimestamp()
        embed2.setFooter(`${interaction.guild.name} Moderation Suite`)
        embed2.setColor(`${guildSettings.colorScheme}`)
        interaction.reply({ embeds: [embed2], ephemeral: false }).catch(err => {})

         db.create({
             caseid: caseId,
             date: Date.now(),
             resmod: interation.user.id,
             offender: user.id,
             reason: reason || 'None Provided.',
             guildId: interation.guild.id,
             type: "Warn"
         })

     }catch(err){
        embed2.setTitle(":pensive: Command Error")
        embed2.setDescription("Seems like we've ran into an error while executing this command, you can view more details below.")
        embed2.addField("Error Message", `${err}`)
        embed2.setColor("RED")
        return interaction.reply({ embeds: [embed2], ephemeral: true }).catch(err => {})
     }



       



    }


}

module.exports = {
    name: "warn",
    description: "Allows you to warn someone in your server.",
    options: [
        {
            name: "user",
            description: "Who would you like to warn?",
            type: "USER",
            required: true
        },
        {
            name: "reason",
            description: "What is the reason for warning this user?",
            type: "STRING",
            required: true
        }
    ],
    run
}