const mongoose = require('mongoose');

const casesSchema = new mongoose.Schema({
    ownerId: String,
    reason: String,
    claimedBy: String,
    ticketId: String
})

module.exports = mongoose.models['tickets'] || mongoose.model('tickets', casesSchema, 'tickets');
