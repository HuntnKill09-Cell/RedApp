const mongoose = require('mongoose');

const casesSchema = new mongoose.Schema({
    guildId: String,
    discordRole: String,
    robloxRole: Number
})

module.exports = mongoose.models['binds'] || mongoose.model('binds', casesSchema, 'binds');

