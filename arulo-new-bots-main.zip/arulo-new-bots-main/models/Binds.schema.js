const mongoose = require('mongoose');

const suggestionSchema = new mongoose.Schema({
    guildId: String,
    rankName: String,
    discordRole: String
})

module.exports = mongoose.models['binds'] || mongoose.model('binds', suggestionSchema, 'binds');