const mongoose = require('mongoose');

const partnersSchema = new mongoose.Schema({
    reps: String,
    robloxid: String,
    discordId: String,
})

module.exports = mongoose.models['partners'] || mongoose.model('partners', partnersSchema, 'partners');