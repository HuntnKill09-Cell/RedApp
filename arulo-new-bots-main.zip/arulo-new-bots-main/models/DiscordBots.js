const { Schema, model } = require("mongoose");

const userSchema = new Schema({
    resourceId: String,
    ownerId: String,
    guildid: String,
    restartBot: Boolean,
    prefix: String,
    groupid: String,
    logchannelid: String,
    modroleid: String,
    supportteamid: String,
    cookie: String,
    mutedroleid: String,
    ticketcadid: String,
    suggestionid: String,
    currentStatus: String,
    customcommands: Array,
    sessions: Array,
    welcometext: String,
    welcomechannel: String,
    welcometitle: String,
    colorScheme: String,
    botToken: String,
    botName: String,
    bindId: String,
    verificationgroupid: String,
    verificationupdaterole: String,
    branding: Boolean,
    roblox: Object,
    sessions: Object,
    botCreationToday: Boolean
});

module.exports = model("customBots", userSchema);
