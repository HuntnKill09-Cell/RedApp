const { Schema, model } = require("mongoose");

const userSchema = new Schema(
  {
    discordId: {
      type: String,
      required: true,
    },
    avatar: {
      type: String,
      required: true,
    },
    username: {
      type: String,
      required: true,
    },
    waitlistMember: {
      type: Boolean,
      required: true,
    },
    currentPlan: {
      type: String,
      required: true,
    },
    createdBots: {
      type: Number,
      required: true,
    },
    createdCounters: {
      type: Number,
      required: true,
    },
    createdLoggers: {
      type: Number,
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

module.exports = model("User", userSchema);
