const { Schema, model } = require("mongoose");

const userSchema = new Schema(
  {
    discordId: {
      type: String,
      required: true,
    },
    reason: {
      type: String,
      required: true,
    },
    notes: {
      type: String,
      required: true,
    },
    userIp: {
        type: String,
        required: true,
    },
    expires: {
        type: String,
        required: true,
    },
    moderator: {
        type: String,
        required: true,
    },
    created_on: {
        type: String,
        required: true,
    },
  },
  {
    timestamps: true,
  }
);

module.exports = model("Suspended", userSchema);
