const mongoose = require('mongoose');
mongoose.connect("mongodb+srv://AruloAdmin:gL8ZGYzIicwndTpa@cluster0.xp2vx.mongodb.net/AruloPlatform?retryWrites=true&w=majority", {useNewUrlParser: true, useUnifiedTopology:true});

const users = require('../models/User.schema')
const accounts = require('../models/Account.schema')
const sessions = require('../models/Sessions.schema')
const guild = require('../models/DiscordBots')
const codes = require('../models/Codes.schema')
const linked = require('../models/LinkedAccounts.schema')
const cases = require('../models/Cases.schema')
const economy = require('../models/Economy.schema')
const suggestion = require('../models/Suggestion.schema')
const partners = require('../models/Partners.schema')
const suspended = require('../models/Suspended')
const tickets = require('../models/Tickets.schema')
const binds = require('../models/Bindings.schema')
const membercounter = require('../models/MemberCounter.schema')

module.exports = { membercounter, suspended, users, accounts, sessions, guild, codes, linked, cases, economy, suggestion, partners, tickets, binds }