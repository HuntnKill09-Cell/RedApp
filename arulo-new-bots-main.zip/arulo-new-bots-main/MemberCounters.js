const db = require('./util/database.util')
const axios = require('axios')
const membercounter = require('./util/database.util').membercounter
const noblox = require('noblox.js')

async function CheckGroups(){

db.membercounter.find((err, documents) => {
    if (err) return console.log(err)
    documents.forEach(async (doc, i) => {
        try{
        let response = await axios.get(`https://groups.roblox.com/v1/groups/${doc.groupid}/roles`)
        const response_count = response.data.roles.reduce((accumulator, value) => accumulator += value.memberCount, 0);

   
   
      if (doc.currentCount === null) {
        await membercounter.updateOne({ groupid: doc.groupid }, { currentCount: response_count })
      }

      function separateComma(val) {
        // remove sign if negative
        var sign = 1;
        if (val < 0) {
          sign = -1;
          val = -val;
        }
        // trim the number decimal point if it exists
        let num = val.toString().includes('.') ? val.toString().split('.')[0] : val.toString();
        let len = num.toString().length;
        let result = '';
        let count = 1;
      
        for (let i = len - 1; i >= 0; i--) {
          result = num.toString()[i] + result;
          if (count % 3 === 0 && count !== 0 && i !== 0) {
            result = ',' + result;
          }
          count++;
        }
      
        // add number after decimal point
        if (val.toString().includes('.')) {
          result = result + '.' + val.toString().split('.')[1];
        }
        // return result with - sign if negative
        return sign < 0 ? '-' + result : result;
      }

      let num = response_count;

      if(doc.firstCount === true){
        try{
            let response2 = await axios.get(`https://groups.roblox.com/v1/groups/${doc.groupid}`)
            await membercounter.updateOne({ groupid: doc.groupid }, { botName: `${response.name}` })
            const embed = new Discord.MessageEmbed()
          embed.setTitle("Successfully created member counter!")
          embed.setDescription("Thanks for creating your member counter using Arulo Platform! We really appreciate the support, if you have any questions and or concerns feel free to contact us via our [Support Server](https://discord.gg/7HJArBnK97)")
          embed.setColor("GREEN")
          embed.setFooter("Feel free to delete this message at any time.")
          await membercounter.updateOne({ groupid: doc.groupid }, { firstCount: false })
          return axios.post(doc.webhook, { embeds: [embed] })
          }catch(err){
            console.log(`Creating It`)
          }
      }

      if (doc.currentCount === 0) {
        try{
            await membercounter.updateOne({ groupid: doc.groupid }, { currentCount: response_count })
          await axios.post(doc.webhook, { content: `${doc.emoji} We are now at **${separateComma(num)}** members in our group! Only ${separateComma(doc.goal - response_count)} to go until **${separateComma(doc.goal)}**!` })
        }catch(err){
            console.log(`Update It`)
          }
        }

        if(doc.goal <= response_count){
            console.log(`${response.name} has reach their member goal of ${separateComma(doc.goal)} members! Increasing it by ${separateComma(doc.increasement)}.`)
            await membercounter.updateOne({ groupid: doc.groupid }, { goal: doc.goal + doc.increasement })
          }
          
    
          if (doc.currentCount === response_count) {
            return
          }

          if(doc.currentCount < response_count) {
            let response2 = await axios.get(`https://groups.roblox.com/v1/groups/${doc.groupid}`)
        
            await membercounter.updateOne({ groupid: doc.groupid }, { currentCount: `${response_count}` })
            console.log(`${response2.data.name} has updated their member count! We are now at ${separateComma(num)} members.`)
            try{
                await axios.post(doc.webhook, { content: `${doc.emoji} We are now at **${separateComma(num)}** members in our group! Only ${separateComma(doc.goal - response_count)} to go until **${separateComma(doc.goal)}**!` })
            }catch(err){
                try{
                    await axios.post("https://discord.com/api/webhooks/990359468950831217/x-DPG7hPyKolhYe5Z0Q0xYKRfoWv4mwMEgkFlcn1qcA0gWbXOKSIFyDvhhOQ8POg8yIN", { content: `**Webhook Error:**\nWebhook Object: \`\`\`js\n${doc}\`\`\`\nError:\n\`\`\``+err.response.data.message+"```"})
                }catch(err){
                    console.log("Error Logs")
                }
            }
          }    

        
        }catch(err){
            console.log(`${err}`)
        }
    })
})
}

//setInterval(check, 20000)
console.log("✔️ Webhook Platform ( Counters ) are currently online.")
CheckGroups().then(() => {
    setInterval(async () => await CheckGroups(), 20000)
})